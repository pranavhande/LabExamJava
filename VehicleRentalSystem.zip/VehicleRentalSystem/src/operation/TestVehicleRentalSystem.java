package operation;

import java.util.*;

import entity.*;
import service.VehicleRentalSystem;

public class TestVehicleRentalSystem {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		VehicleRentalSystem vehicleRentalSystem = new VehicleRentalSystem();

		vehicleRentalSystem.loadInventory();
		vehicleRentalSystem.loadRentals();

		while (true) {
			System.out.println("\n.......Vehicle Rental System.............");
			System.out.println("1. Add Vehicle");
			System.out.println("2. Add Customer");
			System.out.println("3. Rent Vehicle");
			System.out.println("4. Return Vehicle");
			System.out.println("5. Display All Transactions");
			System.out.println("6. Exit");
			System.out.print("Enter your choice: ");
			int choice = sc.nextInt();
			sc.nextLine(); // Clear buffer

			switch (choice) {
			case 1:
				System.out.println("Enter Vehicle ID: ");
				String vehicleId = sc.nextLine();
				System.out.println("Enter Vehicle type: ");
				String type = sc.nextLine();
				Vehicle vehicle = new Vehicle(vehicleId, type);
				vehicleRentalSystem.addVehicle(vehicle);
				break;

			case 2:
				System.out.println("Enter Customer ID: ");
				String customerId = sc.nextLine();
				System.out.println("Enter Customer name: ");
				String name = sc.nextLine();
				Customer customer = new Customer(customerId, name);
				vehicleRentalSystem.addCustomer(customer);
				break;

			case 3:
				System.out.println("Enter Vehicle ID to rent: ");
				vehicleId = sc.nextLine();
				vehicleRentalSystem.rentVehicle(vehicleId);
				break;

			case 4:
				System.out.println("Enter Vehicle ID to return: ");
				vehicleId = sc.nextLine();
				vehicleRentalSystem.returnVehicle(vehicleId);
				break;

			case 5:
				vehicleRentalSystem.displayAllTransactions();
				break;

			case 6:
				System.out.println("...........Thank You For using Vehicle Rental System...........");
				sc.close();
				return;

			default:
				System.out.println("Invalid choice, please try again.");
			}
		}
	}

}
