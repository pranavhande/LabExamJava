package service;

import java.util.ArrayList;

import entity.Rental;

public class Transaction {
	String transactionId;
	ArrayList<Rental> rentals;

	public Transaction(String transactionId) {
		this.transactionId = transactionId;
		this.rentals = new ArrayList<>();
	}

	public void addRental(Rental rental) {
		rentals.add(rental);
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void displayTransactionDetails() {
		System.out.println("Transaction ID: " + transactionId);
		for (Rental rental : rentals) {
			System.out.println("  " + rental.toString());
		}
	}
}
