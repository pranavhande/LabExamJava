package service;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

import entity.*;

public class VehicleRentalSystem {

	private ArrayList<Vehicle> vehicleList = new ArrayList<>();
	private ArrayList<Customer> customerList = new ArrayList<>();
	private ArrayList<Rental> rentalList = new ArrayList<>();
	private ArrayList<Transaction> transactionList = new ArrayList<>();
	private int transactionCounter = 0;

	public void addVehicle(Vehicle vehicle) {
		try {
			if (vehicle == null || vehicle.getVehicleId().isEmpty() || vehicle.getType().isEmpty()) {
				throw new IllegalArgumentException("Vehicle ID and type cannot be empty.");
			}
			vehicleList.add(vehicle);
			System.out.println("Vehicle added successfully.");
			saveVehicleToFile(vehicle);
		} catch (IllegalArgumentException e) {
			System.out.println("Error: " + e.getMessage());
		}
	}

	private void saveVehicleToFile(Vehicle vehicle) {
		try (FileWriter writer = new FileWriter("E:\\logFile1.txt", true);
				BufferedWriter bw = new BufferedWriter(writer)) {
			bw.write(vehicle.toString());
			bw.newLine();
		} catch (IOException e) {
			System.out.println("Error saving vehicle to file: " + e.getMessage());
		}
	}

	public void addCustomer(Customer customer) {
		try {
			if (customer == null || customer.getCustomerId().isEmpty() || customer.getName().isEmpty()) {
				throw new IllegalArgumentException("Customer ID and name cannot be empty.");
			}
			customerList.add(customer);
			System.out.println("Customer added successfully.");
		} catch (IllegalArgumentException e) {
			System.out.println("Error: " + e.getMessage());
		}
	}

	public void rentVehicle(String vehicleId) {
		for (Vehicle vehicle : vehicleList) {
			if (vehicle.getVehicleId().equals(vehicleId)) {
				if (vehicle.isAvailable()) {
					System.out.println("Enter rental ID: ");
					Scanner sc = new Scanner(System.in);
					String rentalId = sc.nextLine();
					System.out.println("Enter rental duration: ");
					String rentalDuration = sc.nextLine();
					Rental rental = new Rental(vehicle, rentalId, rentalDuration);
					addRentalDetails(rental);
					return;
				} else {
					System.out.println("Vehicle is already rented.");
				}
			}
		}
		System.out.println("Vehicle not found.");
	}

	public void addRentalDetails(Rental rental) {
		try {
			if (rental == null) {
				throw new IllegalArgumentException("Rental details cannot be null.");
			}
			rentalList.add(rental);
			System.out.println("Rental details added successfully.");
			saveRentalToFile(rental);
			addTransaction(rental);
		} catch (IllegalArgumentException e) {
			System.out.println("Error: " + e.getMessage());
		}
	}

	private void saveRentalToFile(Rental rental) {
		try (FileWriter writer = new FileWriter("E:\\logFile2.txt", true);
				BufferedWriter bw = new BufferedWriter(writer)) {
			bw.write(rental.toString());
			bw.newLine();
		} catch (IOException e) {
			System.out.println("Error saving rental to file: " + e.getMessage());
		}
	}

	private void addTransaction(Rental rental) {
		transactionCounter++;
		Transaction transaction = new Transaction("T" + transactionCounter);
		transaction.addRental(rental);
		transactionList.add(transaction);
		System.out.println("Transaction created: " + transaction.getTransactionId());
	}

	public void loadInventory() {
		try (BufferedReader br = new BufferedReader(new FileReader("E:\\logFile1.txt"))) {
			String line;
			while ((line = br.readLine()) != null) {
				String[] parts = line.split(" \\(");
				String vehicleId = parts[0].trim();
				String type = parts[1].split("\\)")[0].trim();
				Vehicle vehicle = new Vehicle(vehicleId, type);
				addVehicle(vehicle);
			}
		} catch (IOException e) {
			System.out.println("Error reading inventory from file: " + e.getMessage());
		}
	}
	
	public void loadRentals() {
		try (BufferedReader br = new BufferedReader(new FileReader("E:\\logFile2.txt"))) {
			String line;
			while ((line = br.readLine()) != null) {
				String[] parts = line.split(" \\(");
				String rentalId = parts[0].trim();
				String type = parts[1].split("\\)")[0].trim();
				String duration = parts[2].trim(); 
				Vehicle vehicle = new Vehicle("temp", type); 
				Rental rental = new Rental(vehicle, rentalId, duration);
				rentalList.add(rental);
				System.out.println("Loaded rental: " + rental);
			}
		} catch (IOException e) {
			System.out.println("Error reading rentals from file: " + e.getMessage());
		}
	}
	
	public void displayAllTransactions() {
		if (transactionList.isEmpty()) {
			System.out.println("No transactions available.");
		} else {
			for (Transaction transaction : transactionList) {
				transaction.displayTransactionDetails();
			}
		}
	}

	public void returnVehicle(String vehicleId) {
		for (Vehicle vehicle : vehicleList) {
			if (vehicle.getVehicleId().equals(vehicleId)) {
				if (!vehicle.isAvailable()) {
					vehicle.setAvailable(true);
					System.out.println("Vehicle returned successfully.");
				} else {
					System.out.println("Vehicle is not currently rented.");
				}
				return;
			}
		}
		System.out.println("Vehicle not found.");
	}
}
