package entity;

public class Customer {
	String customerId;
	String name;

	public Customer(String customerId, String name) {
		this.customerId = customerId;
		this.name = name;
	}

	public String getCustomerId() {
		return customerId;
	}

	public String getName() {
		return name;
	}

	public void displayCustomerDetails() {
		System.out.println("Customer [customerId=" + customerId + ", name=" + name + "]");
	}
}
