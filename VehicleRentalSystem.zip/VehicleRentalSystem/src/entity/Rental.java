package entity;

public class Rental {

	String rentalId;
	String rentalDuration;
	Vehicle vehicle;
	boolean isReturned;

	public Rental(Vehicle vehicle, String rentalId, String rentalDuration) {
		this.vehicle = vehicle;
		this.rentalId = rentalId;
		this.rentalDuration = rentalDuration;
		this.isReturned = false;
		this.vehicle.setAvailable(false);
	}

	public String getRentalId() {
		return rentalId;
	}

	public String getRentalDuration() {
		return rentalDuration;
	}

	public boolean isReturned() {
		return isReturned;
	}

	public void returnRental() {
		this.isReturned = true;
		this.vehicle.setAvailable(true);
	}

	@Override
	public String toString() {
		return rentalId + " (" + vehicle.getType() + ") " + rentalDuration;
	}

}
