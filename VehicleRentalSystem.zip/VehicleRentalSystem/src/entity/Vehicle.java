package entity;

public class Vehicle {

	String vehicleId;
	String type;
	boolean isAvailable;

	public Vehicle(String vehicleId, String type) {
		this.vehicleId = vehicleId;
		this.type = type;
		this.isAvailable = true;
	}

	public String getVehicleId() {
		return vehicleId;
	}

	public String getType() {
		return type;
	}

	public boolean isAvailable() {
		return isAvailable;
	}

	public void setAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}

	@Override
	public String toString() {
		return vehicleId + " (" + type + ") " + isAvailable;
	}

}
